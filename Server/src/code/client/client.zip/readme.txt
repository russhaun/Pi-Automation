#These are the files for the home automation client
