import subprocess
import requests
#
def srv_update_check():
        '''pulls down version info from github to compare with client.'''
        info = []
        url = 'https://raw.githubusercontent.com/russhaun/Updates/master/Pi-Automation/Server/ver.txt'
        r = requests.get(url)
        with open("srv_ver.txt", 'w') as v:
                #response is binary have to convert it to utf-8
                response = r.content
                decoded = response.decode(encoding="utf-8")
                #add the version number to our list
                info.append(decoded)
        v.close()
        #delete the version info file. we dont need it any more
        subprocess.call(['cmd', '/C', 'del', 'srv_ver.txt'])
        ver = info[0]
        print("[*] Response from Server:  ok...")
        return(ver)
#
def ClientRestart(pid, status, reason, opt=None, opt1=None):
        '''handles restarting of main script. through either users request or program update. Takes 3 arguments
        status which can be 1 or 0, reason for the restart, and an optional version #. used in the 
        update process'''
        why = reason
        if status == '1':
                if why == 'Software Update':
                        print("[*] Triggering update.\n""[*] " + why + " is starting......")
                        new_ver = opt
                        print("[*] New version detected: " + new_ver + "\n""[*] Unpacking files........")
                        #call unzip routine to extract files and copy over existing files
                        files = opt1
                        #print(files)
                        install_updates(files)
                elif why == '':
                        print("[*] no reason given. I must know why you want to restart.")
                elif why == 'User Restart':
                        print("[*] User initiated restart detected.")
                else:
                        why = reason
                        print("[*] Unknown option. " + reason + ". Please try again." )
        else:
                pass
#
def query_updates(reason, thing):
        '''given a reason and thing will check for updates. future options will include, 
        different threat lists. software updates. log info and things of that nature'''
        #set restart flag to zero
        restart = '0'
        why = reason
        if why == 'Software Update':
                print("[*] Performing checks")
                if thing == 'main':
                        print("[*] Looking for main program updates")
                        update = ClientUpdate(thing)
                        #return update status. 1 is updates found. 0 is nothing found  
                        update_check = update[0]
                        update_files = update[2]
                        #if updates present set restart flag
                        if update_check == '1':
                                restart = '1'
                                ret_version = update[1]
                                why = reason
                                print("[*] Scheduling program restart.")
                        elif update_check == '0':
                                print("[*] Continuing with the load process")
                        else:
                                pass
                        if restart == '1':
                                print("[*] Restart scheduled.")
                                updates = update_files
                                ClientRestart(id, restart, why, ret_version, updates)
                                
                if thing == '':
                        print("[*] need an option to download updates")
                else:
                        pass       
        if why == 'Threat lists':
                print("[*] Looking for Threat Updates")
                if thing == 'banlists':
                        grab_list = ClientUpdate(thing)
                else:
                        pass
        else:
                pass

def ClientUpdate(thing):
    '''Update function for windows.Based on checking a txt file for contents 
    and comparing against a known value if the differ then update and save new value'''
    #set status to zero
    update_status = '0'
    thing_to_update = thing
    if thing_to_update == 'main':
        get_current = get_config('CurrentBuild')
        client_ver = get_current[0]
        #grab current client ver from server
        server_ver = srv_update_check()
        #compare the 2 values and update if different
        if client_ver < server_ver:
                #Schedule update by incrementing counter
                update_status = '1'
                # get files from master branch 
                url = 'https://codeload.github.com/russhaun/Pi-Automation/zip/master'
                r = requests.get(url)
                print("[*] Checking for updates..........\n""[*] New version is availible.\n""[*] Server version: " + server_ver +"\n""[*] Client version: " + client_ver +"\n""[*] Downloading files . Please wait.......")
                # make a nice zip file for later use
                with open("artillery-master_"+ server_ver +".zip" , "wb") as code:
                        code.write(r.content)
                        v = server_ver
                        code.close()
                        srv_update = code
                        return(update_status, v, srv_update)
        else:
                print("[*] Server version: " + server_ver +"\n""[*] Client version: " + client_ver +"\n""[*] You are running the latest version.\n""[*] No updates availible.")
                v = server_ver
                srv_update = '0'
                return(update_status, v, srv_update)
#
#        
def install_updates(updates):
        stuff = updates
        #more_stuff = stuff[0]
        #print(more_stuff)
        path_info = get_path_info()
        #print(path_info[2])
        program_files = path_info[2]
        #print(program_files)
        install_dir = program_files + '\\Artillery'
        print(install_dir)
        pass     
#